package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ChatSessionEntity::class,
        ChatMessageEntity::class,
        TaskEntity::class,
        AgentMemoryEntity::class,
        AgentInstructionEntity::class,
        EvaluationRecordEntity::class,
        SkillEntity::class,
        ScheduledRoutineEntity::class,
        DurableTaskExecutionEntity::class,
        TaskStepEntity::class,
        CloudFileEntity::class,
        ApprovalRequestEntity::class,
        TaskLogEntity::class
    ],
    version = 6,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun chatDao(): ChatDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "open_ai_agent.db"
                )
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
